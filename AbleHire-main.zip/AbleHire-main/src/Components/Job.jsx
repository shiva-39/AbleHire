import React from 'react'
import Infobar from './Infobar'

export default function Job() {
  return (
    <>
        <Infobar/>
    </>
  )
}
